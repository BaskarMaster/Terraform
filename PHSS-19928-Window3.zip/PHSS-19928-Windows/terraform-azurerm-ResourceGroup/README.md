# Introduction 
 This module is to create any number of resource groups or to read the exisitng resource groups which are classified with different versions.

# Getting Started
 Version number starts with '0' has code to read the resource group data where as version number starts with '1' has code to create.

Note that resource group values should define with data type 'Map'. All values to be declared in tfvars file of outer repository.
 This repository have 3 files:
  . main.tf - code is written
  . variables.tf - Declaration and Definition of variables
  . output.tf - output of the code to be used in other modules.


# Build and Test
 . To build/execute this module, one should call it from outher repository using source parameter where the path will be defined and provide the tag name in version paramter.
 . Module variables are to be called as parameters for passing the values.

# Contribute
 . Please check thetags for latest code and contact the project owners for any changes required.