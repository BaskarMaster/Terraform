$creds = new-object pscredential -argumentlist "ENTCORECLOUD.COM\DA_Cyber_15",$(convertto-securestring "sk0{H\Db=R~7p)-#" -asplaintext -force)
Add-Computer -DomainName "ENTCORECLOUD.COM" -credential $creds 
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
Shutdown /r










