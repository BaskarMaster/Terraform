﻿$creds = New-Object pscredential -ArgumentList "username",$(ConvertTo-SecureString "password" -AsPlainText -Force)
Add-Computer -DomainName "domain" -Credential $creds -Restart