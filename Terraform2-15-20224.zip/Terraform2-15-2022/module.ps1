import-module test.ps1
get-date