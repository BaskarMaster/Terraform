# Introduction 
 This module is to create any number of resources or to read the exisitng resource groups which are classified with different versions.
 Specially to create windows and Linux single and multiple machines with the existing resources below. --Resources group, v/net/subnet, storage account, backup and polices.
# Getting Started
 Version number starts with '0' has code to read the resource group data where as version number starts with '1' has code to create.

Note that resource group values should define with data type 'Map'. All values to be declared in tfvars file of outer repository.
 This repository have 4 files:
  . main.tf - code is written
  . variables.tf - Declaration and Definition of variables
  . tfvars - tfvars user can provide to build as per custom requarments.This will call the module and over write in the modules.


# Build and Test
 . To build/execute this module, one should call it from outher repository using source parameter where the path will be defined and provide the tag name in version paramter.
 . Module variables are to be called as parameters for passing the values.

# Contribute
 . Please check thetags for latest code and contact the project owners for any changes required.